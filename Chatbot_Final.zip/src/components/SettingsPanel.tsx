"use client";

import React, { useState } from "react";

export default function SettingsPanel({ apiKeys, onSave }: { apiKeys: any, onSave: (keys: any) => void }) {
  const [keys, setKeys] = useState(apiKeys);
  const [saved, setSaved] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setKeys({ ...keys, [e.target.name]: e.target.value });
    setSaved(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(keys);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div style={{ padding: "2rem", maxWidth: "600px" }} className="animate-fade-in">
      <h2 style={{ marginBottom: "1.5rem" }}>API Configurations</h2>
      <p style={{ color: "var(--text-secondary)", marginBottom: "2rem" }}>
        Enter your API keys below to enable the respective AI models. Keys are stored locally in your browser and are sent to the backend only when generating responses.
      </p>

      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
        <div>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>Google Gemini API Key</label>
          <input 
            type="password" 
            name="google"
            value={keys.google} 
            onChange={handleChange}
            className="input-field"
            placeholder="AIzaSy..."
          />
        </div>

        <div>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>Anthropic API Key</label>
          <input 
            type="password" 
            name="anthropic"
            value={keys.anthropic} 
            onChange={handleChange}
            className="input-field"
            placeholder="sk-ant-..."
          />
        </div>

        <div>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>OpenAI API Key</label>
          <input 
            type="password" 
            name="openai"
            value={keys.openai} 
            onChange={handleChange}
            className="input-field"
            placeholder="sk-proj-..."
          />
        </div>

        <div style={{ marginTop: "1rem", display: "flex", alignItems: "center", gap: "1rem" }}>
          <button type="submit" className="btn-primary">
            Save Configurations
          </button>
          {saved && <span style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>Saved successfully!</span>}
        </div>
      </form>
    </div>
  );
}
