"use client";

import React, { useRef, useEffect, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { Send, Bot, User, Loader2 } from "lucide-react";

export default function ChatInterface({ 
  apiKeys, 
  selectedModel, 
  onModelSelect,
  onUsage
}: { 
  apiKeys: any, 
  selectedModel: string, 
  onModelSelect: (model: string) => void,
  onUsage: (tokens: number) => void
}) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [input, setInput] = useState("");

  const transport = React.useMemo(() => new DefaultChatTransport({
    api: "/api/chat",
    body: {
      apiKeys,
      model: selectedModel,
    }
  }), [apiKeys, selectedModel]);

  const { messages, sendMessage } = useChat({
    transport,
  });

  // Mock loading state
  const isLoading = messages.length > 0 && messages[messages.length - 1].role === "user";

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    sendMessage({ text: input });
    setInput("");
    onUsage(Math.floor(Math.random() * 50) + 10);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }} className="animate-fade-in">
      {/* Header */}
      <header style={{ padding: "1rem 1.5rem", borderBottom: "1px solid rgba(255,255,255,0.05)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h3 style={{ fontWeight: "600" }}>Sales Context Bot</h3>
        <select 
          className="input-field" 
          style={{ width: "220px", padding: "0.5rem" }}
          value={selectedModel}
          onChange={(e) => onModelSelect(e.target.value)}
        >
          <optgroup label="Google">
            <option value="google:gemini-1.5-pro">Gemini 1.5 Pro</option>
            <option value="google:gemini-1.5-flash">Gemini 1.5 Flash</option>
          </optgroup>
          <optgroup label="Anthropic">
            <option value="anthropic:claude-3-5-sonnet-20240620">Claude 3.5 Sonnet</option>
            <option value="anthropic:claude-3-haiku-20240307">Claude 3 Haiku</option>
          </optgroup>
          <optgroup label="OpenAI">
            <option value="openai:gpt-4o">GPT-4o</option>
            <option value="openai:gpt-4o-mini">GPT-4o Mini</option>
          </optgroup>
        </select>
      </header>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: "1.5rem", display: "flex", flexDirection: "column", gap: "1rem" }}>
        {messages.length === 0 ? (
          <div style={{ margin: "auto", textAlign: "center", color: "var(--text-secondary)" }}>
            <Bot size={48} style={{ margin: "0 auto 1rem auto", opacity: 0.5 }} />
            <p>Start a conversation with the Sales Bot.</p>
            <p style={{ fontSize: "0.85rem", marginTop: "0.5rem" }}>Make sure your API keys are configured in Settings.</p>
          </div>
        ) : (
          messages.map((m) => {
            const textContent = m.parts?.map(p => p.type === 'text' ? p.text : '').join('') || '';
            return (
              <div key={m.id} style={{ display: "flex", gap: "1rem", flexDirection: m.role === "user" ? "row-reverse" : "row" }}>
                <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: m.role === "user" ? "var(--accent-color)" : "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  {m.role === "user" ? <User size={18} /> : <Bot size={18} />}
                </div>
                <div style={{ 
                  background: m.role === "user" ? "rgba(59, 130, 246, 0.15)" : "rgba(255,255,255,0.05)", 
                  padding: "1rem", 
                  borderRadius: "12px", 
                  border: m.role === "user" ? "1px solid rgba(59, 130, 246, 0.3)" : "1px solid rgba(255,255,255,0.05)",
                  maxWidth: "80%",
                  lineHeight: "1.6"
                }}>
                  {textContent}
                </div>
              </div>
            );
          })
        )}
        {isLoading && (
          <div style={{ display: "flex", gap: "1rem" }}>
            <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "rgba(255,255,255,0.1)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Bot size={18} />
            </div>
            <div style={{ padding: "1rem", display: "flex", alignItems: "center", gap: "0.5rem", color: "var(--text-secondary)" }}>
              <Loader2 size={16} className="animate-spin" style={{ animation: "spin 2s linear infinite" }} /> Generating response...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div style={{ padding: "1.5rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <form onSubmit={handleSubmit} style={{ position: "relative" }}>
          <input
            className="input-field"
            style={{ paddingRight: "3rem", padding: "1rem", borderRadius: "12px", background: "rgba(0,0,0,0.3)" }}
            value={input}
            onChange={handleInputChange}
            placeholder="Ask a question..."
            disabled={isLoading}
          />
          <button 
            type="submit" 
            disabled={isLoading || !input.trim()}
            style={{ position: "absolute", right: "0.5rem", top: "50%", transform: "translateY(-50%)", padding: "0.5rem", color: isLoading || !input.trim() ? "var(--text-secondary)" : "var(--accent-color)" }}
          >
            <Send size={20} />
          </button>
        </form>
      </div>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes spin { 100% { transform: rotate(360deg); } }
      `}} />
    </div>
  );
}
