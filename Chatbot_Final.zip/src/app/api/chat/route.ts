import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { createAnthropic } from "@ai-sdk/anthropic";
import { createOpenAI } from "@ai-sdk/openai";
import { streamText } from "ai";

export const maxDuration = 30;

export async function POST(req: Request) {
  const { messages, apiKeys, model } = await req.json();

  const [provider, modelName] = model.split(":");

  if (!apiKeys || !apiKeys[provider]) {
    return new Response(JSON.stringify({ error: `Missing API key for ${provider}. Please configure it in settings.` }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }

  let selectedModel;

  if (provider === "google") {
    const google = createGoogleGenerativeAI({
      apiKey: apiKeys.google,
    });
    selectedModel = google(modelName);
  } else if (provider === "anthropic") {
    const anthropic = createAnthropic({
      apiKey: apiKeys.anthropic,
    });
    selectedModel = anthropic(modelName);
  } else if (provider === "openai") {
    const openai = createOpenAI({
      apiKey: apiKeys.openai,
    });
    selectedModel = openai(modelName);
  } else {
    return new Response("Invalid provider", { status: 400 });
  }

  // Define system prompt for Context Bot
  const systemPrompt = `You are the Sales Bot MVP. 
Your ultimate goal is to flawlessly answer queries based exclusively on the context or data provided by the user.
Cleanly compile the outputs into properly arranged text formats.
Be professional, accurate, and concise.`;

  const result = await streamText({
    model: selectedModel,
    system: systemPrompt,
    messages,
  });

  return result.toTextStreamResponse();
}
