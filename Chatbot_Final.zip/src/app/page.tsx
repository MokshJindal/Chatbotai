"use client";

import React, { useState, useEffect } from "react";
import ChatInterface from "../components/ChatInterface";
import SettingsPanel from "../components/SettingsPanel";
import { MessageSquare, Settings, Database, Activity } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState("chat");
  const [apiKeys, setApiKeys] = useState({
    openai: "",
    anthropic: "",
    google: "",
  });
  const [selectedModel, setSelectedModel] = useState("google:gemini-1.5-pro");
  const [usageCredits, setUsageCredits] = useState(0);
  const WARNING_THRESHOLD = 5000;

  useEffect(() => {
    // Load settings from local storage on mount
    const savedKeys = localStorage.getItem("apiKeys");
    if (savedKeys) setApiKeys(JSON.parse(savedKeys));

    const savedModel = localStorage.getItem("selectedModel");
    if (savedModel) setSelectedModel(savedModel);

    const savedUsage = localStorage.getItem("usageCredits");
    if (savedUsage) setUsageCredits(parseInt(savedUsage, 10));
  }, []);

  const handleSaveKeys = (keys: any) => {
    setApiKeys(keys);
    localStorage.setItem("apiKeys", JSON.stringify(keys));
  };


  const handleModelSelect = (model: string) => {
    setSelectedModel(model);
    localStorage.setItem("selectedModel", model);
  };

  const incrementUsage = (tokens: number) => {
    const newUsage = usageCredits + tokens;
    setUsageCredits(newUsage);
    localStorage.setItem("usageCredits", newUsage.toString());
  };

  return (
    <div className="main-content" style={{ flexDirection: "row", height: "100vh" }}>
      {/* Sidebar */}
      <aside className="glass-panel" style={{ width: "260px", margin: "1rem", display: "flex", flexDirection: "column", border: "1px solid rgba(255,255,255,0.05)", background: "rgba(19, 27, 47, 0.4)" }}>
        <div style={{ padding: "1.5rem", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
          <h2 style={{ fontSize: "1.25rem", display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <Activity color="#3b82f6" /> SalesBot MVP
          </h2>
        </div>

        <nav style={{ padding: "1rem", flex: 1, display: "flex", flexDirection: "column", gap: "0.5rem" }}>
          <button
            className={`btn-secondary ${activeTab === "chat" ? "active-nav" : ""}`}
            style={{ justifyContent: "flex-start", background: activeTab === "chat" ? "rgba(59, 130, 246, 0.1)" : "transparent", border: activeTab === "chat" ? "1px solid rgba(59, 130, 246, 0.3)" : "1px solid transparent" }}
            onClick={() => setActiveTab("chat")}
          >
            <MessageSquare size={18} /> Context Chat
          </button>

          <button
            className={`btn-secondary ${activeTab === "data" ? "active-nav" : ""}`}
            style={{ justifyContent: "flex-start", background: activeTab === "data" ? "rgba(59, 130, 246, 0.1)" : "transparent", border: activeTab === "data" ? "1px solid rgba(59, 130, 246, 0.3)" : "1px solid transparent" }}
            onClick={() => setActiveTab("data")}
          >
            <Database size={18} /> Feed Data
          </button>

          <button
            className={`btn-secondary ${activeTab === "settings" ? "active-nav" : ""}`}
            style={{ justifyContent: "flex-start", background: activeTab === "settings" ? "rgba(59, 130, 246, 0.1)" : "transparent", border: activeTab === "settings" ? "1px solid rgba(59, 130, 246, 0.3)" : "1px solid transparent" }}
            onClick={() => setActiveTab("settings")}
          >
            <Settings size={18} /> Settings & Keys
          </button>
        </nav>

        <div style={{ padding: "1rem", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem", fontSize: "0.85rem", color: "var(--text-secondary)" }}>
            <span>Credits Used</span>
            <span>{usageCredits}</span>
          </div>
          <div style={{ height: "6px", background: "rgba(255,255,255,0.1)", borderRadius: "3px", overflow: "hidden" }}>
            <div style={{
              height: "100%",
              width: `${Math.min((usageCredits / WARNING_THRESHOLD) * 100, 100)}%`,
              background: usageCredits > WARNING_THRESHOLD ? "var(--warning-color)" : "var(--accent-color)"
            }} />
          </div>
          {usageCredits > WARNING_THRESHOLD && (
            <div style={{ marginTop: "0.5rem", fontSize: "0.75rem", color: "var(--warning-color)" }}>
              Warning: High credit usage detected.
            </div>
          )}
        </div>
      </aside>

      {/* Main Area */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", margin: "1rem 1rem 1rem 0" }}>
        {usageCredits > WARNING_THRESHOLD && (
          <div className="glass-panel animate-fade-in" style={{ padding: "1rem", marginBottom: "1rem", background: "rgba(245, 158, 11, 0.1)", border: "1px solid rgba(245, 158, 11, 0.3)", color: "var(--warning-color)", display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <Activity size={18} /> You have exceeded the recommended usage threshold ({WARNING_THRESHOLD} credits). The service is still active.
          </div>
        )}

        <div className="glass-panel" style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: "rgba(19, 27, 47, 0.6)" }}>
          {activeTab === "chat" && (
            <ChatInterface
              apiKeys={apiKeys}
              selectedModel={selectedModel}
              onModelSelect={handleModelSelect}
              onUsage={incrementUsage}
            />
          )}
          {activeTab === "settings" && (
            <SettingsPanel
              apiKeys={apiKeys}
              onSave={handleSaveKeys}
            />
          )}
          {activeTab === "data" && (
            <div style={{ padding: "2rem" }}>
              <h2>Feed Data (Context Ingestion)</h2>
              <p style={{ color: "var(--text-secondary)", marginTop: "1rem" }}>
                Paste context below for the bot to learn.
              </p>
              <textarea
                className="input-field"
                style={{ height: "300px", marginTop: "1rem", resize: "none" }}
                placeholder="Paste document text here..."
              ></textarea>
              <button className="btn-primary" style={{ marginTop: "1rem" }}>Save Context</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
